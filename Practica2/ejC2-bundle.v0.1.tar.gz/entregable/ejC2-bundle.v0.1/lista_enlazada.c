#include "lista_enlazada.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


lista_t* nueva_lista(void) {

}

uint32_t longitud(lista_t* lista) {

}

void agregar_al_final(lista_t* lista, uint32_t* arreglo, uint64_t longitud) {

}

nodo_t* iesimo(lista_t* lista, uint32_t i) {
}

uint64_t cantidad_total_de_elementos(lista_t* lista) {
}

void imprimir_lista(lista_t* lista) {
}

// Función auxiliar para lista_contiene_elemento
int array_contiene_elemento(uint32_t* array, uint64_t size_of_array, uint32_t elemento_a_buscar) {
}

int lista_contiene_elemento(lista_t* lista, uint32_t elemento_a_buscar) {

}


// Devuelve la memoria otorgada para construir la lista indicada por el primer argumento.
// Tener en cuenta que ademas, se debe liberar la memoria correspondiente a cada array de cada elemento de la lista.
void destruir_lista(lista_t* lista) {
}